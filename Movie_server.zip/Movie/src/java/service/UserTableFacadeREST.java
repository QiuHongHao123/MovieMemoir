/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import movie_entity.UserTable;

/**
 *
 * @author 31588
 */
@Stateless
@Path("movie_entity.usertable")
public class UserTableFacadeREST extends AbstractFacade<UserTable> {

    @PersistenceContext(unitName = "MoviePU")
    private EntityManager em;

    public UserTableFacadeREST() {
        super(UserTable.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(UserTable entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, UserTable entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public UserTable find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<UserTable> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<UserTable> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @GET
    @Path("findBySurname/{Surname}")
    @Produces({"application/json"})
    public List<UserTable> findBySurname(@PathParam("Surname") String Surname) 
    {         
        Query query = em.createNamedQuery("UserTable.findBySurname");         
        query.setParameter("surname", Surname);         
        return query.getResultList();    
    }
    @GET
    @Path("findByDob/{dob}")
    @Produces({"application/json"})
    public List<UserTable> findByDob(@PathParam("dob") Date dob) 
    {         
        Query query = em.createNamedQuery("UserTable.findByDob");         
        query.setParameter("dob", dob);         
        return query.getResultList();    
    }
    @GET
    @Path("findByAddress/{address}")
    @Produces({"application/json"})
    public List<UserTable> findByAddress(@PathParam("address") String address) 
    {         
        Query query = em.createNamedQuery("UserTable.findByAddress");         
        query.setParameter("address", address);         
        return query.getResultList();    
    }
    @GET
    @Path("findByState/{state}")
    @Produces({"application/json"})
    public List<UserTable> findByState(@PathParam("state") String state) 
    {         
        Query query = em.createNamedQuery("UserTable.findByState");         
        query.setParameter("state", state);         
        return query.getResultList();    
    }
    @GET
    @Path("findByGender/{gender}")
    @Produces({"application/json"})
    public List<UserTable> findByGender(@PathParam("gender") String gender) 
    {         
        Query query = em.createNamedQuery("UserTable.findByGender");         
        query.setParameter("gender", gender);         
        return query.getResultList();    
    }
    @GET
    @Path("findByPostcode/{postcode}")
    @Produces({"application/json"})
    public List<UserTable> findByPostcode(@PathParam("postcode") String postcode) 
    {         
        Query query = em.createNamedQuery("UserTable.findByPostcode");         
        query.setParameter("postcode", postcode);         
        return query.getResultList();    
    }
    @GET
    @Path("findByUserName/{userName}")
    @Produces({"application/json"})
    public List<UserTable> findByUserName(@PathParam("userName") String userName) 
    {         
        Query query = em.createNamedQuery("UserTable.findByUserName");         
        query.setParameter("userName", userName);         
        return query.getResultList();    
    }
        
    @GET     
    @Path("findUserByName_gender/{surname}/{userName}/{gender}")     
    @Produces({"application/json"})     
    public List<UserTable> findUserByName_gender(@PathParam("surname") String surname,@PathParam("userName") String userName,@PathParam("gender") String gender) {         
        TypedQuery<UserTable> q = em.createQuery("SELECT u FROM UserTable u WHERE u.surname = :surname and u.userName=:userName and u.gender=:gender" , UserTable.class);         
        q.setParameter("userName", userName);    
        q.setParameter("surname", surname);  
        q.setParameter("gender", gender);  
        return q.getResultList();     
    } 
    
    @GET     
    @Path("getMaxId")     
    @Produces({MediaType.APPLICATION_JSON}) 
     public Object getMaxId() {         
        Query query = em.createQuery("select max(u.userId) from UserTable u ");
        
        List<Object>  result =query.getResultList();    
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder(); 
        for(Object row:result){
        JsonObject dateObject = Json.createObjectBuilder().add("MAXID",(Integer) row).build();
        arrayBuilder.add(dateObject); 
   
                }
        JsonArray jArray = arrayBuilder.build(); 
        return jArray;
    } 
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
