/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;

import java.util.List;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import movie_entity.Memoir;

/**
 *
 * @author 31588
 */
@Stateless
@Path("movie_entity.memoir")
public class MemoirFacadeREST extends AbstractFacade<Memoir> {

    @PersistenceContext(unitName = "MoviePU")
    private EntityManager em;

    public MemoirFacadeREST() {
        super(Memoir.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Memoir entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Memoir entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public Memoir find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_JSON})
    public List<Memoir> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }
    @GET 
    @Path("findByMovieName/{MovieName}")     
    @Produces({"application/json"})     
    public List<Memoir> findByMovieName(@PathParam("MovieName") String MovieName) 
    {         
        Query query = em.createNamedQuery("Memoir.findByMovieName");         
        query.setParameter("movieName", MovieName);         
        return query.getResultList();    
    }
    @GET 
    @Path("findByScore/{MemoirScore}")     
    @Produces({"application/json"})     
    public List<Memoir> findByScore(@PathParam("MemoirScore") double Score) 
    {         
        Query query = em.createNamedQuery("Memoir.findByScore");         
        query.setParameter("score", Score);         
        return query.getResultList();    
    }
    @GET 
    @Path("findByWatchTime/{Watchtime}")     
    @Produces({"application/json"})     
    public List<Memoir> findByWatchTime(@PathParam("Watchtime") Date Watchtime) 
    {         
        Query query = em.createNamedQuery("Memoir.findByWatchTime");         
        query.setParameter("watchTime", Watchtime);         
        return query.getResultList();    
    }
    @GET 
    @Path("findByReleaseDate/{ReleaseDate}")     
    @Produces({"application/json"})     
    public List<Memoir> findByReleaseDate(@PathParam("ReleaseDate") Date ReleaseDate) 
    {         
        Query query = em.createNamedQuery("Memoir.findByReleaseDate");         
        query.setParameter("releaseDate", ReleaseDate);         
        return query.getResultList();    
    }
    @GET 
    @Path("findMemoirByCinemalocation/{Cinemalocation}/{movieName}")     
    @Produces({"application/json"})     
    public List<Memoir> findMemoirByCinemalocation(@PathParam("Cinemalocation") String Cinemalocation,@PathParam("movieName") String movieName) 
    {         
        Query query = em.createNamedQuery("Memoir.findMemoirByCinemalocation");         
        query.setParameter("cinemaLocation", Cinemalocation);    
        query.setParameter("movieName", movieName); 
        return query.getResultList();    
    }
    
    @GET     
    @Path("findMenmoirByCinemaName/{Cinemaname}/{movieName}")     
    @Produces({"application/json"})     
    public List<Memoir> findMenmoirByCinemaName(@PathParam("Cinemaname") String Cinemaname,@PathParam("movieName") String movieName) {         
        TypedQuery<Memoir> q = em.createQuery("SELECT m FROM Memoir m WHERE m.cinemaId.cinemaName = :Cinemaname and m.movieName=:movieName" , Memoir.class);         
        q.setParameter("Cinemaname", Cinemaname);    
        q.setParameter("movieName", movieName);  
        return q.getResultList();     
    } 
    
    @GET     
    @Path("findMemoir4_a/{user_id}/{start_date}/{end_date}")     
    @Produces({MediaType.APPLICATION_JSON})     
    public Object findMemoir4_a(@PathParam("user_id") int user_id,@PathParam("start_date") Date start_date,@PathParam("end_date") Date end_date) {         
        Query query = em.createQuery("select m.cinemaId.cinemaLocation,count(m)  from Memoir m where m.userId.userId= :user_id and m.watchTime  between :start_date and :end_date group by m.cinemaId.cinemaLocation ");
        query.setParameter("user_id", user_id);
        query.setParameter("start_date", start_date);
        query.setParameter("end_date", end_date);
        List<Object[]>  result =query.getResultList();    
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder(); 
        for(Object[] row:result){
        JsonObject personObject = Json.createObjectBuilder().add("location",(String) row[0]).add("num",(Long) row[1]).build();
        arrayBuilder.add(personObject); 
        
                }
        JsonArray jArray = arrayBuilder.build(); 
        return jArray;
    } 
    @GET     
    @Path("findMemoirDepartByYear4_b/{user_id}/{year}")     
    @Produces({MediaType.APPLICATION_JSON})     
    public Object findMemoirDepartByYear4_b(@PathParam("user_id") int user_id,@PathParam("year") Integer year) { 
        Date Year1=Date.valueOf(String.valueOf(year)+"-01-01");
        Date Year2=Date.valueOf(String.valueOf(year+1)+"-01-01");
        Query query = em.createQuery("select m.watchTime from Memoir m where m.watchTime between :Year1 and :Year2 and m.userId.userId=:user_id ");
        query.setParameter("user_id", user_id);
        query.setParameter("Year1", Year1);
        query.setParameter("Year2", Year2);
        List<Date>  result =query.getResultList();
        int num[]= new int[13];
        Calendar cal = Calendar.getInstance();        
        for(java.util.Date row : result){
            cal.setTime(row);
            int month=cal.get(Calendar.MONTH);
            num[month+1]+=1;
        }
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder(); 
        for(int i=1;i<num.length;i++){
        JsonObject personObject = Json.createObjectBuilder().add("month",i).add("number",num[i]).build();
        arrayBuilder.add(personObject); 
        
                }
        JsonArray jArray = arrayBuilder.build(); 
        return jArray;
    } 
    @GET     
    @Path("findHighestMovie4_c/{user_id}")     
    @Produces({MediaType.APPLICATION_JSON})     
    public Object findHighestMovie4_c(@PathParam("user_id") int user_id) {     
        
        Query query = em.createQuery("select m.movieName, m.score ,m.releaseDate from Memoir m where m.userId.userId= :user_id and m.score=( select max(m.score) from Memoir m where m.userId.userId= :user_id )");
        query.setParameter("user_id", user_id);
        List<Object[]>  result =query.getResultList();    
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder(); 
        for(Object[] row:result){
        JsonObject dataObject = Json.createObjectBuilder().add("movie_name",(String) row[0]).add("score",(double) row[1]).add("release_date",((java.util.Date) row[2]).toString()).build();
        arrayBuilder.add(dataObject); 
        
                }
        JsonArray jArray = arrayBuilder.build(); 
        return jArray;
    } 
    @GET     
    @Path("WatchMovieAtSametime4_d/{user_id}")     
    @Produces({MediaType.APPLICATION_JSON})     
    public Object WatchMovieAtSametime4_d(@PathParam("user_id") int user_id) {     
        Query query1 = em.createQuery("select m.memoirId,m.watchTime,m.releaseDate from Memoir m where m.userId.userId= :user_id ");
        query1.setParameter("user_id", user_id);
        List<Object[]>  result1 =query1.getResultList(); 
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        Calendar cal = Calendar.getInstance();      
        for(Object[]row:result1){
            cal.setTime((java.util.Date)row[1]);
            int year1=cal.get(Calendar.YEAR);
            cal.setTime((java.util.Date)row[2]);
            int year2=cal.get(Calendar.YEAR);
            //Get the memoir id
            if(year1==year2){
                Query query = em.createQuery("select m.movieName from Memoir m where m.memoirId = :memoirId");
                query.setParameter("memoirId", row[0]);
                List  result =query.getResultList(); 
                JsonObject dataObject = Json.createObjectBuilder().add("movie_name",(String) result.get(0))
                        .add("year",year1).build();
                arrayBuilder.add(dataObject); 
                
            }           
        }
        
        JsonArray jArray = arrayBuilder.build(); 
        return jArray;
    } 
    
    
    @GET     
    @Path("WatchRemark4_e/{user_id}")     
    @Produces({MediaType.APPLICATION_JSON}) 
     public Object WatchRemark4_e(@PathParam("user_id") int user_id) {         
        Query query = em.createQuery("select m.movieName,m.releaseDate from Memoir m where m.userId.userId= :user_id  group by m.movieName,m.userId.userId,m.releaseDate having count(m)>1 ");
        query.setParameter("user_id", user_id);
        List<Object[]>  result =query.getResultList();    
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder(); 
        for(Object[] row:result){
        JsonObject dateObject = Json.createObjectBuilder().add("moviename",(String) row[0]).add("releaseDate",((java.util.Date)row[1]).toString()).build();
        arrayBuilder.add(dateObject); 
        
                }
        JsonArray jArray = arrayBuilder.build(); 
        return jArray;
    } 
         
    @GET     
    @Path("RecentHignestMovie4_f/{user_id}")     
    @Produces({MediaType.APPLICATION_JSON}) 
     public Object RecentHignestMovie4_f(@PathParam("user_id") int user_id) {   
        Calendar date = Calendar.getInstance();
        String year = String.valueOf(date.get(Calendar.YEAR));
        Date Year1=Date.valueOf(year+"-01-01");
        Date Year2=Date.valueOf(year+"-12-31");
        Query query = em.createQuery("select DISTINCT m.movieName,m.releaseDate,m.score top5 from Memoir m where m.userId.userId= :user_id and m.releaseDate between :Year1 and :Year2 order by m.score ");
        query.setParameter("user_id", user_id);
        query.setParameter("Year1", Year1);
        query.setParameter("Year2", Year2);
        List<Object[]>  result =query.getResultList();    
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder(); 
        for(Object[] row:result){
        JsonObject dateObject = Json.createObjectBuilder().add("moviename",(String) row[0]).add("releaseDate",((java.util.Date)row[1]).toString()).add("score",(double) row[2]).build();
        arrayBuilder.add(dateObject); 
        
                }
        JsonArray jArray = arrayBuilder.build(); 
        return jArray;
    } 
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}